import xmind
from xmind.core.topic import TopicElement
from memory_profiler import profile
import copy
import csv

class DataStructure():
    def __init__(self):
        self.path = [] # 用例的路径
        self.precondition = [] #预定义条件
        self.step_respects = [] #步骤，或者期望结果
        self.title = ""

    def addPrecondition(self,precondition):
        self.precondition.append(precondition)

    def addStepOrRespects(self,title):
        self.step_respects.append(title)

    def addPath(self,title):
        self.path.append(title)

    def setTitle(self,title=""):
        if title != "":
            self.title = title
            return True

        if self.title == "":
            if len(self.path) > 0:
                self.title = self.path.pop(-1)
                return True
            else:
                self.title = ""
                return False

    def getpath(self):
        if len(self.path)>0:
            return ">".join(self.path)
        else:
            return ""

    def gettitle(self):
        return self.title

    def getprecondition(self):
        if len(self.precondition) == 0:
            return ""
        else:
            return ",".join(self.precondition)

    def getsteps(self):
        if len(self.step_respects) > 0:
            return self.step_respects[0]

    def getrespects(self):
        if len(self.step_respects) > 1:
            return self.step_respects[1]

    def clearStepAndResult(self):
        self.step_respects = []

    def clearTitle(self):
        self.title = ""


class Case():
    def __init__(self,path,casename,precondition,steps,respects,priority="meddle"):
        self.path = path
        self.title = casename
        self.precondition = precondition
        self.priority = priority
        self.steps = steps
        self.respects = respects
        self.headerdict = {
            ""
        }
        self.support_fields = [
            '路径', "用例名称", "预置条件", "优先级", "执行步骤", "期望结果"
        ]
    def print(self):
        print("*"*20)
        print("执行路径: ",self.path)
        print("用例名称: ",self.casename)
        print("优先级: ",self.priority)
        print("预定义条件：",self.precondition)
        print("步骤：",self.steps)
        print("期望结果: ",self.respects)

def buildCase(datastruct):
    path = datastruct.getpath()
    casename = datastruct.gettitle()
    precondition = datastruct.getprecondition()
    steps = datastruct.getsteps()
    respects = datastruct.getrespects()
    case = Case(path,casename,precondition,steps,respects)
    return case

def isPrecondition(title):
    return title.find("前置条件") >= 0

def isStepOrRespects(title):
    return title.strip()[0].isdigit()

def readxmind(fname):
    xmindbook = xmind.load(fname)
    # return xmindbook
    sheets = xmindbook.getSheets()
    return sheets

def getSheetByindex(xmindbook,index=0):
    sheets = xmindbook.getSheets()
    if index > len(sheets)-1:
        return sheets[-1]
    else:
        return sheets[index]

def resoveNode(node:TopicElement,path,cases):
    title = node.getTitle()
    subtopics = node.getSubTopics()
    subtopiclen = len(subtopics)
    handled = False
    if isPrecondition(title):
        path.addPrecondition(title)
        handled = True
    elif isStepOrRespects(title):
        path.addStepOrRespects(title)
        path.setTitle()
        handled = True

    if subtopiclen == 0:
        if not handled:
            path.setTitle(title)
        # else:
        case = buildCase(copy.deepcopy(path))
        cases.append(case)
        path.clearStepAndResult()
        path.clearTitle()
        return
    else:
        if not handled:
            path.addPath(title)

    for subtopic in subtopics:
        resoveNode(subtopic, copy.deepcopy(path), cases)

def resolvSheet(sheet):
    pass

def writeToCsv(fname,cases):
    header = ['路径',"创建人","用例名称", "预置条件", "优先级", "执行步骤", "期望结果"]
    headerdict = {
        "路径":"path",
        "用例名称":"title",
        "预置条件":"precondition",
        "优先级":"priority",
        "执行步骤":"steps",
        "期望结果":"respects",
        "创建人":"creater"
    }
    with open(fname,"w",encoding="utf-8") as f:
        csv_writer = csv.writer(f)
        csv_writer.writerow(header)
        for case in cases:
            row = []
            for item in header:
                if item in case.support_fields:
                    row.append(eval("case."+headerdict[item]))
                else:
                    row.append("")
            csv_writer.writerow(row)
    # with open(fname,"w",encoding="utf-8") as f:
    #     csv_writer = csv.writer(f)
    #     csv_writer.writerow(header)
    #     for case in cases:


# @profile
def test(fname):
    xmindbook = xmind.load(fname)
    sheet = xmindbook.getSheets()[0]
    topic = sheet.getRootTopic()
    path = DataStructure()
    cases = []
    resoveNode(topic,path,cases)
    return cases
    # for case in cases:
    #     case.print()

if __name__ == '__main__':
    fname = "/Users/eddie/Documents/sample.xmind"
    cases = test(fname)
    writeToCsv("test.csv",cases)
    # xmindbook = xmind.load(fname)
    # return xmindbook
    # sheet0 = xmindbook.getSheets()[0]

